var express = require('express');
var router = express.Router();
var Sales = require('../model/sales');

/* GET sales page. */
router.get('/', function(req, res, next) {
  Sales.find({}, function(err,docs){
  	if(!err) {
  		res.render("sales",{"sales": docs, "title": "Sales Report"});
  	}
  })
});

module.exports = router;
