var express = require('express');
var router = express.Router();
var Sales = require('../model/sales');

/* GET sales RESTful request. */
router.get('/', function(req, res, next) {
  Sales.find({}, function(err,docs){
  	if(!err) {
  		res.json(docs);
  	}
  })
});

/* GET sales based on id RESTful request. */
router.get('/:quarter', function(req, res, next) {
  Sales.find({"quarter": req.params.quarter}, function(err,docs){
  	if(!err) {
  		res.json(docs);
  	}
  })
});

/* POST sales REST */
router.post('/', function(req, res, next) {
  Sales.create(req.body, function(err,docs){
  	if(!err) {
  		res.send("Sales added Succefully!!!");
  	}
  });
});

module.exports = router;
