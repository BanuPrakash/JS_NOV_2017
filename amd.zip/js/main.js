require.config({
	'baseUrl': 'js',
	'paths' : {
		'jquery' : '../lib/jquery',
		'underscore' : '../lib/underscore-min',
		'text' : '../lib/text'
	}
});

require(["repo/productDao",
		"jquery",
		"underscore",
		"text!../templ/products.html"], 
		function(productDao, $, _, productTemplate){
			var compiledTempl = _.template(productTemplate);
			productDao.init();
			$(document.body).append(compiledTempl({"products": productDao.get()}));
		});