
JavaScript, NodeJS, Angular 4
Banu Prakash C
banuprakashc@yahoo.co.in
banu@advantech-global.com
banu@lucidatechnologies.com
-----------------------------------

Softwares Required:
1) Chrome Browser
2) Editors: Sublime Text 3 and Visual Studio Code
3) Node JS: Latest [LTS]
4) MongoDB Community Edition Database Server
---------------------------------------------
  JavaScript --> Scripting Language, loosely typed , event driven

  ECMA 5 --> JS 5 

  JS needs JavaScript engines for execution

  V8 --> Google ---> used in Chrome and NODEJS env
  NashHorn --> Sun/ Oracle ---> used by most of oracle products
  SpiderMonkey -->  ---> FireFox and Most of Adobe's products
  Chakra --> MS --> IE
  Continnium ---> MS ---> Edge

  ------------------

  variables and scope

  first.js

  var data = 100;

  function doTask() {
  	var a = 10;
  	if(data > a) {
  		var b = 15; // hoisting to function scope
  		c = 88; // hoisted to global scope
  	}
  	console.log(data, a, b, c); //

  		function someTask() {
  			var a = 22;
  			console.log(a, b, data);
  		}
  }
  doTask();
  console.log(data, a, b, c);

  ---------------

  function add(x, y) {
  	var result = x + y;
  }

  var ans = add(4,5); 

  console.log(ans); // undefined undefined

 ---------------

 function add(x, y) {
  	var result = x + y;
  		return	result;
  }

  var ans = add(4,5); 
   console.log(ans); // 9

 -------------------------

  Every JS function is a "Function" object

   var add = new Function("x","y", " return x + y");

    var ans = add(4,5); 
   console.log(ans); // 9

  ----------------------------

  number, string, boolean, undefined, null, object, array

  ---------------------------------------

  JavaScript Object Oriented Programming:

  Object creation:

  1) var obj = new Object();

  	obj.id = 12; // state
  	obj.name = "Raj"; // state

  	obj.getDetails = function() {
  		return this.id + ", " + this.name;
  	}

  	console.log(obj.getDetails()); // 12, Raj

  2) var nobj = Object.create(obj); 

  	nobj.age = 22;


  3) Constructor Pattern:

  	function Employee(name, age) {
  		this.name = name;
  		this.age = age;
  		//INSTANCE METHOD OWNED BY OBJECTS
  		this.getDetails = function() {
  			return this.name +", " + this.age;
  		}
  	}

  	var e1 = new Employee("A",22);
  	var e2 = new Employee("B",28);

  	-----------

  	function Employee(name, age) {
  		this.name = name;
  		this.age = age;
   	}

   	//INSTANCE METHOD OWNED BY CLASS
  		Employee.prototype.getDetails = function() {
  			return this.name +", " + this.age;
  		}
  	var e1 = new Employee("A",22);
  	var e2 = new Employee("B",28);


  	sort(fn) {
  		for(i = 0; i < ... ) {
  			for(j = i + 1; ...) {
  				if(fn(msgs[i], msgs[j])) {
  					//swap
  				}
  			}
  		}
  	}

  4) JSON
  		JavaScript Object Notation

  	var obj = {};

  	var e1 = {
  		"id": 122,
  		"name" : "smith",
  		"getInfo": function() {
  			return this.id + ", " + this.name;
  		}

  	};

  	e1.getInfo();
 ----------------------------------------------------

 	High Order functions:

 		1) functions which accept functions as arguments
 		2) functions which return a function

 	Common high order functions we use are:

 	a) MAP
 	b) REDUCE
 	c) FILTER
 	d) SORT
 	e) ITERATE



 	var data = [34,25,7,2,22,41];

 	for(var i = 0; i < data.length; i++) {
 		console.log(data[i]);
 	}

 	for(var i = 0; i < data.length; i++) {
 		alert(data[i]);
 	}

 	for(var i = 0; i < data.length; i++) {
 		writeToFile(data[i]);
 	}

 	---

 	function iterate(elems, action) {
 		for(var i = 0; i < elems.length; i++) {
 			action(elems[i]);
 		}
 	}

 	iterate(data, console.log);
 	iterate(data, alert);
 	iterate(data, writeToFile);

  -----------------

  	function greeting(msg, name) {
  		return msg + " " + name;
  	}

  	greeting("Good Morning", "Smith");
  	greeting("Good Morning", "Peter");
  	greeting("Good Day", "Roger");
  	greeting("Good Morning", "Smith");


  	function greeting(msg) {
  		return function(name) {
  			return msg + " " + name;
  		}
  	}

  	var morningGreet = greeting("Good Morning");
  	var generalGreet = greeting("Good Day");

  	morningGreet("Roger");
-------------------------------------------------------------------

 IIFE --> Immedietly invoke function expression [ Self - invoking function]
 (function() {

 })();

 JS Patterns:
  1) Module Pattern
  2) Factory Pattern
  3) Memoize pattern
  4) Observer
  5) Chain of Responsibility
  6) Singleton Pattern

  Module Pattern
  --------------
   ==> brings the concept of modular code, visbility , encapsulation

   var m1 =  (function() {
    	var x;

    	function doTask() {

    	}

    		return {
    			"task": doTask
    		}
 	})();

 	 (function() {
    	var x;

    	function doTask() {
    		m1.task();
    	}
 	})();


 	Factory Pattern:
 	-----------	----

 		var obj = {
 			"id": 11;
 		}

 		obj.id;

 		obj["id"];

 	---------------------

 	Observer Pattern
 -------------------------------------------------------------------

 	ES 2015 --> ECMA 2015 ---> JS 6

 	1) Scope variable and constant

 		var data = 100;

		  function doTask() {
		  	var a = 10;
		  	if(data > a) {
		  		let b = 15; // block scope
		  		c = 88; // hoisted to global scope
		  	}
		  	console.log(data, a, b, c); // b is not visible

		  		function someTask() {
		  			var a = 22;
		  			console.log(a, b, data);
		  		}
		  }
		  doTask();
		  console.log(data, a, b, c);


		  const PI = 3.14159;

		  for(var i = 0; i < 5; i++) {

		  }

		  value of "i" is visible here

		    for(let i = 0; i < 5; i++) {

		  }

		  i is not visible here


	2) New String literal  ``

		' ' and " "

		var sentence = ` Jack and Jill
				 went up the hill. To ....`;


		var name = "Smith";

		var greet = `Welcome ${name}`;


	3) Deconstructing

		var colors = ["red","green","blue","pink","orange"];

		// old way

		var r = colors[0];
		var g = colors[1];

		// deconstructing in ES6

		var [r,g,b,...others] = colors;

	4) Arrow operator

		var add = function(x,y) {
			return x + y;
		}

		console.log(add(4,5));


		var sub = (x,y) => {
			return x - y;
		}

		or
		var sub = (x,y) =>   x - y;

	5) class keyword

		function Employee(name, age) {
			this.name = name;
			this.age = age;
		}

		NEW ES6 way:

		class Employee {
			name;
			age;

			constructor(n, a) {
				this.name = name;
				this.age = age;
			}

			getDetails() {
				return this.name + ", " + this.age;
			}

			static hello() {

			}
		}
	 
		let e1 = new Employee("A", 22);
		e1.getDetails();


	TRANSPILERS ---> BABEL

	ES6 --> BABEL --> ES5

	6) PROMISE
		$q, bluebird

		Sync call

		var result = serverSideCode();


		Async:
			serverSideCode().then(function() {

			},
			function() {

			});

			remaining code....

	7) Modules

		datalib.js

		exports.add = function() {

		}

		exports.sub = function() {

		}

		test.js

		import {add, sub} from '/datalib';

		console.log(add());
 ----------------------------------------

 	Module and AMD

 	Asynchronous Module Definitions
 	REquireJS
 	CommonJS [ node JS]

 	https://github.com/BanuPrakash/JS_NOV_2017

 	download amd.zip

  Nodejs Download

  npm i -g http-server

  
