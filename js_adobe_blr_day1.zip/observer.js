
var subject = {
	observers : {},
	subscribe: function(event, fn) {
		this.observers[event] = this.observers[event] || [];
		this.observers[event].push(fn);
	},
	notify : function(event, data) {
		this.observers[event].forEach(function(fn) {
			fn(data);
		})
	}
};

// list module
(function() {
	var div = document.getElementById("listView");
	function render(data) {
		var content = "";
		data.forEach(function(p) {
			content += p.id +"," + p.name +"<br />";
		});
		div.innerHTML = content;
	};
	subject.subscribe("add_event", render);
})();

// statsModule
(function() {
	var div = document.getElementById("statsView");
	function render(data) {
		div.innerHTML = "#" + data.length;
	};
	subject.subscribe("add_event", render);
})();

//form module
(function() {
	var products = [{"id":1,"name":"A"},{"id":2,"name":"B"} ];

	var btn = document.getElementById("addBtn");
	btn.addEventListener("click", function() {
		var id = document.getElementById("id").value;
		var name = document.getElementById("name").value;
		products.push({
			id : id,
			name : name
		});
		subject.notify("add_event", products);
	});
})();