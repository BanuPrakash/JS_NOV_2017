function iterate(elems, action) {
 		for(var i = 0; i < elems.length; i++) {
 			action(elems[i]);
 		}
}

function map(elems, mappingFn) {
	var result = [];
	iterate(elems, function(elem){
		result.push(mappingFn(elem));
	});
	return result;
}

function filter(elems, predicate) {
	var result = [];
	iterate(elems, function(elem){
		if(predicate(elem)) {
			result.push(elem);
		}
	});
	return result;
}
