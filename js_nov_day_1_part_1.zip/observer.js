var subject = {
	observers : {},
	subscribe: function(evt, fn) {
		this.observers[evt] = this.observers[evt] || [];
		this.observers[evt].push(fn);
	},

	notify: function(evt, data) {
			this.observers[evt].forEach(function(fn) {
					fn(data);
			});
	}
};

// gridView
(function(){
	var elem = document.getElementById("gridView");
	function _render(data) {
		var content = "";
		data.forEach(function(d) {
				content += d.id + "," + d.name + "<br />";
		});
		elem.innerHTML = content;
	}
	subject.subscribe("add_evt", _render);
})();
//statsView
(function(){
	var elem = document.getElementById("statsView");
	function _render(data) {
			elem.innerHTML = "#" + data.length;
	}
	subject.subscribe("add_evt", _render);
})();
//forView
(function(){
	var prds = [{"id":1,"name":"A"}, {"id":2,"name":"B"}];
	document.getElementById("addBtn").addEventListener("click", function() {
		var id = document.getElementById("id").value;
		var name = document.getElementById("name").value;
		prds.push({
			id : id,
			name : name
		});
		subject.notify("add_evt", prds);
	})
})();
